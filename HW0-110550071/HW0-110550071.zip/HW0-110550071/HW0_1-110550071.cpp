#include<iostream>
using namespace std;
int main(){
	string str;
	cin >> str;
	cout << "Hello " << str << "!";
}
